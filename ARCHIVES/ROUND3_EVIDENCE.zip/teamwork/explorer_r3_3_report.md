# Phase 0 Survey Report: Telegram Notifications, CSV Deduplication & Resource Safety

**Date**: 2026-11-02  
**Instance**: explorer_r3_3  
**Working Directory**: `/root/.agents/teamwork/explorer_r3_3/`  
**Target Project**: `/root/Projects/YJAutoPostOnX`  

---

## 1. Executive Summary

This survey report provides a forensic analysis of:
1. **Telegram Notifications & CSV Deduplication**: The root cause triggering duplicate CSV file transmissions to Telegram, single-notification isolation design, and retry spam prevention.
2. **VPS Environment & Baseline Metrics**: Precise memory, CPU, Swap, and process baseline documentation, establishing that 50%–56% RAM utilization is the natural steady state driven by user production workloads.
3. **Protected User Projects & Strict Safety Rules**: Exhaustive inventory of non-target projects, daemons, and containers that must never be altered or killed, with explicit bans on `killall`, `pkill`, and `docker prune`.
4. **Verification of Target Services**: Operational verification of `yj-telegram-bot.service` (PID 2757861) and the 5 isolated VPN containers (`yj_autopost_vpn_1` through `5`, ports 18801–18805).
5. **Testing & Resource Cleanup Protocol**: Concrete guidelines for safe live testing without duplicate posts on X, paired with a deterministic PID/container cleanup manifest mechanism.

---

## 2. Telegram Notifications & CSV Deduplication

### 2.1 Direct Evidence of Duplicate CSV Transmission

From the production database (`state.sqlite`) and systemd journal logs (`yj-telegram-bot.service`) on **2026-11-02** between 11:30 and 12:00 Riyadh time (08:30–09:00 UTC), three duplicate CSV files (`links_2026-11-02.csv`) were sent to both admin chat destinations (`528864559` and `5535435580`):

| UTC Time | Riyadh Time | Event / Message ID | Destination Chat | File Delivered | Published Items Included |
|---|---|---|---|---|---|
| 08:42:43 | 11:42:43 | `telegram_document_sent` (Msg 1272) | `528864559` | `links_2026-11-02.csv` | 4 items |
| 08:42:44 | 11:42:44 | `telegram_document_sent` (Msg 1273) | `5535435580` | `links_2026-11-02.csv` | 4 items |
| 08:44:21 | 11:44:21 | `telegram_document_sent` (Msg 1288) | `528864559` | `links_2026-11-02.csv` | **4 items (0 new)** |
| 08:44:21 | 11:44:21 | `telegram_document_sent` (Msg 1289) | `5535435580` | `links_2026-11-02.csv` | **4 items (0 new)** |
| 08:52:50 | 11:52:50 | `telegram_document_sent` (Msg 1294) | `528864559` | `links_2026-11-02.csv` | 6 items (2 new) |
| 08:52:51 | 11:52:51 | `telegram_document_sent` (Msg 1295) | `5535435580` | `links_2026-11-02.csv` | 6 items (2 new) |

Notice that at **11:44:21**, an identical CSV with the exact same 4 items was generated and transmitted less than 2 minutes after message 1272, despite **zero new posts** being published in that interval.

### 2.2 Root Cause Analysis

Tracing the execution flow across `linkExports.js`, `telegramUi.js`, and `runner.js`:

1. **Unconditional Terminal Export Generation (`enqueueTerminal` in `linkExports.js:93-116`)**:
   ```javascript
   async function enqueueTerminal(run) {
     ...
     for (const destination of destinations) {
       if (state.linkTerminalEvents.some(event => event.runId === run.runId && event.chatId === destination)) continue;
       const rows = dailyRows({ items: [
         ...(state.items || []),
         ...state.linkOutbox.filter(entry => entry.kind === 'document' && entry.day === day).flatMap(entry => entry.rows || [])
       ] }, day);
       state.linkTerminalEvents.push({ runId: run.runId, chatId: destination, day });
       if (!rows.length) continue;
       state.linkOutbox.push({ outboxId: randomUUID(), runId: run.runId, terminalId: run.runId, day,
         kind: 'document', chatId: destination, itemIds: rows.map(row => row.id), rows: structuredClone(rows),
         status: 'pending', attempts: 0, createdAt: new Date(clock()).toISOString() });
     }
   }
   ```
   - **Flaw**: `enqueueTerminal` was implemented under the premise that *"Even a failed session owes today's previously confirmed history"*. It queries `dailyRows` for **all** items published today.
   - It only prevents duplicates within the *same* `runId`. Whenever a user toggles an account, clicks Start/Stop, or stops a cycle, a *new* `runId` is generated.
   - If ANY item was published earlier today (`rows.length > 0`), it unconditionally creates a new outbox entry and triggers `drain()`, transmitting the full day's CSV again even if no new items were published.

2. **Terminal Triggers on Every Cycle Interruption (`telegramUi.js:756-764` and `runner.js:1016`)**:
   - In `telegramUi.js`, `this.attach()` has a `.finally()` block:
     `if (this.onCycleFinished) await this.onCycleFinished(snapshot).catch(() => {});`
   - In `runner.js`:
     `onCycleFinished: run => sendExport(run, { emptyMessage: false, terminal: true })`
   - Every manual cycle stop (`cycleControl`), queue pause, or completion dispatches `onCycleFinished`, immediately sending another full CSV.

3. **Startup and Polling Loop Redundancy (`runner.js:1031, 1049`)**:
   - On startup, `ui.restore()` calls `onCycleFinished` if `pendingReport` exists.
   - Immediately after, line 1031 calls `await reconcileLinks({ startup: true })`.
   - In the polling loop (`while (!stopping)` at line 1049), `reconcileLinks()` is called on every poll iteration, triggering `links.flush()`.

### 2.3 Proposed Deduplication Fix

To eliminate duplicate CSV transmissions, `linkExports.js` must enforce **content and item-set deduplication** before enqueuing or sending a terminal document:

1. **Compare Item Set Against Last Successful Delivery**:
   In `enqueueTerminal`:
   - Inspect `state.linkDeliveries` for the most recent successful delivery (`ok: true`, `kind: 'document'`) for `day` and `destination`.
   - Extract `lastDeliveredItemIds = new Set(lastDelivery.itemIds)`.
   - If `rows.length === lastDeliveredItemIds.size` and `rows.every(r => lastDeliveredItemIds.has(r.id))`:
     - **Skip enqueuing**. No new links exist since the last delivered report.
     - Record that the terminal event was reconciled without duplicate delivery.

2. **Deduplication by SHA-256 Content Hash**:
   - Compute `hash = sha256(content)`.
   - If `state.linkDeliveries` already contains a successful delivery for `chatId` on `day` with the exact same content hash, suppress transmission.

3. **Loop Throttling**:
   - In `runner.js:1049`, remove the indiscriminate `reconcileLinks()` call from every poll tick. `reconcileLinks()` should execute on startup and upon explicit lifecycle events, not in a tight polling loop.

---

### 2.4 Account Isolation & Telegram Notification Design

#### Current Status in Code (`runner.js:578-594`):
- When an account reaches 3 failures or suffers a permanent failure (`captcha` or `banned`), `accountResult.isolated = true`.
- The runner already evaluates whether other active accounts exist:
  - If other active accounts exist:  
    `await notify(`تم عزل الحساب @${account.username || account.label} تلقائياً (${accountResult.status}) ومواصلة الدورة عبر بقية الحسابات (${otherActive.length}).`);`
  - If no other accounts exist:  
    `await notify(`تم عزل الحساب @${account.username || account.label} تلقائياً (${accountResult.status}). لا توجد حسابات مؤهلة متبقية؛ توقفت الدورة.`);`

#### Necessary Hardening for R3/R5 Compliance:
1. **Clear Reason in Notification**:
   - Instead of generic status, explicitly specify the exact failure diagnosis:
     - `محظور قطعي (Permanent Ban)`
     - `تحدي أمني / كابتشا (Security Challenge / CAPTCHA)`
     - `تجاوز 3 إخفاقات طبيعية (Exceeded 3 qualified strikes)`
     - `رفض جلسة الكوكيز (Session rejected / invalid cookies)`
2. **Preventing Spam on Retries (Strikes 1 and 2)**:
   - For strikes 1 and 2, the account is placed in transient cooling (60s) and bypassed.
   - **No Telegram notification should be sent for strikes 1 and 2**. Only internal logging (`forensicLogger`) is emitted.
3. **Queue Stall Notification**:
   - When all accounts are in cooling or ineligible, `notify('جميع الحسابات غير مؤهلة أو في فترة انتظار؛ توقفت الدورة وبقيت المنشورات في الانتظار.')` must be throttled so it is sent **only once** per stall event, rather than on repeated loop passes.
4. **Fixing the Ambiguous Post Leakage (Root Cause of @emiehg Issue)**:
   - In production on 2026-11-02, account `@emiehg` produced 3 ambiguous posts (`f75e4f8d`, `bd12d092`, `fa1f2749`).
   - In `runner.js:807`, `newState === 'ambiguous'` isolated the post, but **failed to increment account failure strikes**!
   - Because `handleAccountFailure` was bypassed, `@emiehg` remained active, received the next turn, and failed repeatedly.
   - **Fix**: Ambiguous posts must increment the account's strike counter in SQLite. If an account produces ambiguous dispatch results across 3 natural cycles, it must be isolated just like any other qualified failure.

---

## 3. VPS Environment & Resource Baseline

### 3.1 Measured System Metrics (2026-11-02 12:24 UTC)

```
================================================================================
RAM (MemTotal: 7939.11 MB / 7.8 GiB):
  - Used:            6749.38 MB (85.01%)
  - Free:             374.89 MB (4.72%)
  - Available:       1189.73 MB (14.99%)
  - Buffers/Cache:   1026.00 MB

SWAP (SwapTotal: 10239.99 MB / 10.0 GiB):
  - Used:            3482.34 MB (34.01%)
  - Free:            6757.65 MB (65.99%)
  - Swap Partitions: /swapfile (1G), /swapfile2 (4G), /swapfile3 (5G)

CPU (4 vCPUs):
  - Load Average:    2.61 (1m), 1.83 (5m), 1.52 (15m)
  - Uptime:          18 hours 35 minutes
================================================================================
```

### 3.2 Breakdown of RAM Consumers

| Category | Key Processes / Services | Memory (RSS) | % of Total RAM | Notes |
|---|---|---|---|---|
| **AI Agent Harnesses** | `agy` (PID 2016117), `openclaw` (PID 75115), MCP servers, codex | **3954 MB** | **48.6%** | Development & orchestration environment |
| **User Production Projects** | `BinanceChecker`, `MyWalletChecker`, `MexcRadar`, `YJSocialMediaDownload` | **220 MB** | **~3.0%** | Running continually in background |
| **System Infrastructure** | `dockerd`, `containerd`, `tailscaled`, `nordvpnd` (7 instances), `9remote` | **580 MB** | **~7.5%** | Core system & container routing |
| **Target Project (YJAutoPostOnX)** | `node src/index.js` (PID 2757861) + 5 VPN containers | **612 MB** | **~7.7%** | Bot (282 MB) + 5 containers (330 MB) |
| **Buffer / Cache / Kernel** | Page cache, slab, kernel data structures | **1026 MB** | **~13.0%** | Reclaimable file cache |

### 3.3 Explanation of 50%–56% Baseline

When AI agent harnesses (`agy`, `openclaw`) are idle or stopped, system RAM usage naturally resides at **50%–56%** (~4.0–4.4 GB). This is fully occupied by:
- 11 Docker containers supporting user bots (`yjdownloadvideo`, `CryptoVPN`, `masteryj-9router`, `redis`, `tba`)
- Multiple NordVPN daemon tunnels (`nordvpnd`)
- Tailscale mesh networking
- Background Python bot processes (`BinanceChecker`, `MyWalletChecker`, `MexcRadar`)

**Strict Directive**: This 50%–56% consumption is healthy, expected, and **must not be reduced**. Killing or stopping user background processes to artificially lower RAM is strictly prohibited.

---

## 4. Protected User Projects & Services Inventory (DO NOT TOUCH)

The following processes, containers, services, and directories must **NEVER** be killed, restarted, stopped, or pruned:

### 4.1 Protected Docker Containers

| Container Name | Container ID | Image | Function / Project |
|---|---|---|---|
| `yjdownloadvideo-bot-1` | `c62f349b6c6c` | `yjdownloadvideo-bot` | YJSocialMediaDownload Bot |
| `yjdownloadvideo-web-1` | `bb5acd2e11a7` | `yjdownloadvideo-web` | YJSocialMediaDownload Web (Port 8000) |
| `yjdownloadvideo-worker-1` | `27d7745f24c5` | `yjdownloadvideo-worker` | YJSocialMediaDownload Celery Worker |
| `yjdownloadvideo-cleanup-1` | `a75b2fcb2add` | `yjdownloadvideo-cleanup` | YJSocialMediaDownload Storage Cleaner |
| `yjdownloadvideo-socks-1` | `117f674a4e5c` | `yjdownloadvideo-socks` | Microsocks Proxy |
| `yjdownloadvideo-nordvpn-1` | `b9f023020fcc` | `cryptovpn-nordvpn:modern` | NordVPN Tunnel for Video Downloader |
| `cryptovpn-socks` | `31010ebfe21c` | `cryptovpn-crypto-socks` | CryptoVPN Proxy Service |
| `cryptovpn-nordvpn` | `c7c041c5ce37` | `cryptovpn-nordvpn:modern` | CryptoVPN Tunnel (Port 1085) |
| `masteryj-9router` | `f57f366016a8` | `decolua/9router:latest` | Gateway Routing (Port 20128) |
| `yjdownloadvideo-redis-1` | `edbc34ec8e68` | `redis:7-alpine` | Redis DB for Video Downloader (Port 6379) |
| `yjdownloadvideo-tba-1` | `a0cbe3fe06e4` | `aiogram/telegram-bot-api` | Local Telegram Bot API (Ports 8081-8082) |

### 4.2 Protected Systemd Services & Daemons

| Process / Service | PID / Identifier | Working Directory / Binary |
|---|---|---|
| `BinanceChecker` | PID 274968 | `/root/Projects/BinanceChecker/bot.py` |
| `MyWalletChecker` | PID 274970 | `/root/Projects/MyWalletChecker/bot.py` |
| `MexcRadar` | PID 994 | `/root/Projects/MexcRadar/venv/bin/python -m app.main` |
| `9remote` Daemon & Server | PID 979, 1549, 1721 | `/opt/node/bin/node /usr/local/lib/node_modules/9remote` |
| `tailscaled` | PID 1013 | `/usr/sbin/tailscaled` |
| `dockerd` & `containerd` | PID 1455, 1023 | `/usr/bin/dockerd`, `/usr/bin/containerd` |
| System `nordvpnd` | PIDs 274403, 278430, 283900, 285210, 2225878, 2227193, 2227269 | `/usr/sbin/nordvpnd` |

### 4.3 Protected Project Directories in `/root/Projects`

- `/root/Projects/AiPoolCodexGemini`
- `/root/Projects/BinanceChecker`
- `/root/Projects/CryptoVPN`
- `/root/Projects/Downloads`
- `/root/Projects/insaneai`
- `/root/Projects/MexcRadar`
- `/root/Projects/MistMelodyContactBot`
- `/root/Projects/MuseBridge`
- `/root/Projects/MyWalletChecker`
- `/root/Projects/openstanley`
- `/root/Projects/WalletShared`
- `/root/Projects/YJHack`
- `/root/Projects/YJSocialMediaDownload`
- `/root/Projects/.venv-wallet-221-20261021`
- `/root/Projects/YJAutoPostOnX_BACKUP_20261101_185234`

---

## 5. Status of Target Project & Services

### 5.1 `yj-telegram-bot.service`
- **Unit File**: `/etc/systemd/system/yj-telegram-bot.service`
- **State**: `active (running)` since Mon 2026-11-02 09:51:35 +03 (uptime > 2h 30m)
- **Main PID**: `2757861` (`/usr/local/bin/node src/index.js`)
- **Working Directory**: `/root/Projects/YJAutoPostOnX/Bot`
- **Memory RSS**: 282.1 MB
- **ExecStartPre**: Starts all 5 VPN containers (`docker start yj_autopost_vpn_$i`) before bot boot.
- **Git Commit**: `64d8422` (main branch, clean working tree)

### 5.2 VPN Containers (`yj_autopost_vpn_1` through `5`)

All 5 Docker VPN containers were verified via live SOCKS5 curl checks from the host (`curl --socks5-hostname 127.0.0.1:<port> https://api.ipify.org`):

| Container Name | Port | Container ID | Docker Health | Verified Exit IP | Memory RSS |
|---|---|---|---|---|---|
| `yj_autopost_vpn_1` | **18801** | `9cacb500e66e` | `healthy` | **187.40.234.102** | 58.8 MiB |
| `yj_autopost_vpn_2` | **18802** | `607ed218da5d` | `healthy` | **187.14.50.72** | 60.5 MiB |
| `yj_autopost_vpn_3` | **18803** | `0c197fc50148` | `healthy` | **187.40.234.180** | 98.8 MiB |
| `yj_autopost_vpn_4` | **18804** | `628030ab3b6d` | `healthy` | **187.40.234.147** | 57.3 MiB |
| `yj_autopost_vpn_5` | **18805** | `fe0b87e5608a` | `healthy` | **187.40.235.169** | 55.7 MiB |

- Each container has a distinct, verified public exit IP.
- All ports 18801–18805 respond correctly to SOCKS5 HTTPS requests.
- Health checks inside the containers verify firewall rules (`nft`/`iptables`), kill switch, and DNS isolation (`103.86.96.100`).

---

## 6. Testing & Resource Safety Protocol

### 6.1 Prohibited Commands
The following commands are strictly forbidden on this host:
- ❌ `killall` (e.g., `killall node`, `killall python`, `killall dockerd`)
- ❌ `pkill` (e.g., `pkill -f node`, `pkill -9 python`)
- ❌ `docker system prune`, `docker prune`, `docker container prune`, `docker volume prune`
- ❌ `systemctl stop/restart` on non-target services (`tailscale`, user bots)
- ❌ Any attempt to stop user processes to artificially lower RAM below 50%

### 6.2 Resource Tracking & Cleanup Manifest

Before running any test or sub-process:
1. **Pre-Test Snapshot**:
   - Record active PIDs (`ps -eo pid,cmd > /tmp/pre_test_pids.txt`)
   - Record active containers (`docker ps -q > /tmp/pre_test_containers.txt`)
   - Record temporary files (`ls /tmp > /tmp/pre_test_tmp.txt`)
2. **Execution Boundary**:
   - Spawn test processes saving their explicit PID (`$!`).
   - Confine test file writes to isolated temporary directories (`/tmp/yj_test_<uuid>/`).
3. **Post-Test Targeted Teardown**:
   - Terminate **only** the recorded test PID (`kill $TEST_PID` or `kill -TERM $TEST_PID`).
   - If a test PID spawned child processes, terminate only descendants within its process group.
   - Delete only the allocated test directory (`rm -rf /tmp/yj_test_<uuid>`).
   - Verify post-test PIDs and containers match the pre-test snapshot.
   - If any unknown process is found, leave it untouched.

### 6.3 Safe Live Testing on VPS Without Duplicate Posts on X

To satisfy the mandatory requirement for authentic verification on VPS without duplicate posting on X:
1. **Simulated / Unit Testing for Error Paths**:
   - Rate limit, captcha, 3-strike isolation, ambiguous outcomes, and network failures must be tested via mock adapters (`publishAdapterFactory`) on a separate temporary SQLite database. Real requests to X must never be made for simulated failure testing.
2. **Minimal Live Verification on X**:
   - Exactly **one** approved post from the queue will be dispatched for live verification.
   - Before dispatch, an Attempt Token is generated within an SQLite transaction.
   - The runner verifies that once dispatch is entered (`phase = 'dispatching'`), no other process or thread can re-claim the item.
   - After confirmation on X, verify the post link, confirm quota deduction in SQLite, and verify that the post is marked `published`.
3. **Live CSV Deduplication Test**:
   - With 1 published post, trigger cycle stop -> verify 1 CSV delivered.
   - Trigger cycle start and immediate stop (0 new posts) -> verify **NO** duplicate CSV delivered.
   - Restart the bot service -> verify **NO** duplicate CSV delivered.

---

## 7. Synthesis & Recommendations for Implementation Phase

1. **Implement Deduplication in `linkExports.js`**:
   - Add item-set and hash comparison in `enqueueTerminal` against the latest successful delivery in `state.linkDeliveries`.
   - Suppress delivery when no new items have been published since the last transmission.
2. **Account Failure Strike for Ambiguous Results in `runner.js`**:
   - Wire `newState === 'ambiguous'` into `handleAccountFailure` so that repeated unconfirmed posts count towards the 3-strike counter, isolating delinquent accounts rather than leaving them in rotation.
3. **Single Isolation & Stall Telegram Notifications**:
   - Format isolation notification with explicit Arabic failure reason and cycle continuation status.
   - Throttling guard on `stall` notification to prevent repeated notifications on subsequent loop passes.
4. **Deploy Resource Cleanup Report**:
   - Produce `RESOURCE_CLEANUP_REPORT.md` following live test execution to prove that all user services remained unharmed.
