# Project: YJAutoPostOnX — Production Recovery & Operational Verification (Round 3)

## Architecture
- **Layer 1: Telegram UI & Lifecycle Control** (`Bot/src/telegramUi.js`, `Bot/src/singleInstance.js`, `Bot/src/linkExports.js`):
  Handles operator commands, dynamic account toggling (up to 5 active accounts), singleton bot locking, and deduplicated CSV export delivery.
- **Layer 2: Queue & Account Management** (`Bot/src/queue.js`, `Bot/src/accounts.js`, `Bot/src/quota.js`, `Bot/src/db.js`):
  Manages post states, pre-dispatch claimed state protection, natural rotation order, independent per-account Riyadh daily quotas, and persistent state in SQLite.
- **Layer 3: Execution Runner & Fault Isolation** (`Bot/src/runner.js`):
  Coordinates execution, 3-strikes accounting on natural turns for ambiguous and qualifying account failures, temporary turn skipping on strikes 1 and 2, immediate isolation on 3 strikes or confirmed ban, excluding network/VPN/proxy errors from account failure counts, and immediate pre-dispatch post transfers.
- **Layer 4: Direct X Python Bridge & Network Isolation** (`Bot/python/direct_x_bridge.py`, `direct_x_compat.py`, `Bot/src/dockerVpn.js`):
  Performs authenticated X actions over independent SOCKS5 proxies (18801-18805) backed by NordVPN containers (`yj_autopost_vpn_1..5`), with timeline verification and precise 8-class diagnostic classification.

## Feature Inventory
| # | Feature | Description | Milestone | Source |
|---|---------|-------------|-----------|--------|
| 1 | Ambiguous 3-Strike Accounting | Invoke `handleAccountFailure` on ambiguous post outcomes; count strike on natural turn, cool account, and isolate upon 3rd strike | M1 | Survey |
| 2 | Ambiguous Item Account Attribution | Persist `accountId` and `accountUsername` to SQLite items table for ambiguous posts to maintain audit trail | M1 | Survey |
| 3 | Exclude Network/VPN from Account Strikes | Differentiate transient network/proxy/VPN container errors from account faults; do not penalize account failure counter | M1 | Survey |
| 4 | Pre-Dispatch Post Protection | In `queue.js:recoverProcessing`, do not quarantine unattempted posts (`attempt.phase === 'claimed'`); transfer to next account if account fails pre-dispatch | M1 | Survey |
| 5 | Multi-Account Independence & 5 Active Limit | Ensure strict independence of quota, cookies, Docker slot, and VPN proxy across accounts, enforcing max 5 active accounts | M1 | Survey |
| 6 | Python Twikit Response & Timeline Handling | Fix `create_tweet` returning `None` in `direct_x_bridge.py`; verify user timeline before returning unverified/ambiguous | M2 | Survey |
| 7 | Granular 8-Class Diagnostics | Ensure precise diagnosis across banned, captcha, cookie_expired, auth_rejected, rate_limit, network_proxy_error, ambiguous, unknown | M2 | Survey |
| 8 | CSV Export Deduplication | Compare pending terminal export rows with `state.linkDeliveries` in `linkExports.js`; suppress duplicate CSVs on cycle stop | M3 | Survey |
| 9 | Single Isolation Alert & Retry Spam Suppression | Send single clear Arabic Telegram alert on account isolation; silence individual retry attempts; alert on queue stall | M3 | Survey |
| 10 | Telegram 409 Conflict Resilience | Harden `SingleInstanceLock` and `getUpdates` error recovery against external collision | M3 | Survey |
| 11 | VPS Live Operational Verification | Live verification on VPS service (`yj-telegram-bot.service`), VPN rotation, limited real X post, quota deduction, CSV arrival | M4 | Survey |
| 12 | Strict Resource Safety & Clean Handoff | Pre/post test PID and container tracking, zero impact on user processes/services, cleanup reports, git push, ZIP delivery | M5 | Survey |

## Milestones
| # | Name | Scope | Dependencies | Status |
|---|------|-------|-------------|--------|
| M1 | Core Runner & Queue Fixes | `runner.js`, `queue.js`, `accounts.js` (3-strikes on ambiguous, attribution, network error separation, pre-dispatch protection, cooling awareness) | Survey | DONE (71/71 tests PASS, Gate PASS) |
| M2 | Python Bridge & Diagnostics | `direct_x_bridge.py`, `direct_x_compat.py` (Twikit `None` handling, timeline verification, 8-class diagnosis) | M1 | DONE (183/183 tests PASS, Gate PASS) |
| M3 | Telegram & CSV Deduplication | `linkExports.js`, `telegramUi.js`, `singleInstance.js` (CSV deduplication, single isolation alert, retry spam suppression) | Survey | DONE (82/82 tests PASS, Gate PASS) |
| M4 | VPS Live Operational Testing | Live testing on VPS bot service, VPN rotation, limited X publish, quota deduction, CSV arrival, safe fault injection | M1, M2, M3 | DONE (16/16 operational tests PASS, Tweet 2117218878304801135 verified, Gate PASS) |
| M5 | Audit, Cleanup & Delivery | Forensic integrity audit (teamwork_auditor), `RESOURCE_CLEANUP_REPORT.md`, `MASTER_TODO.md`, `PROGRESS_HISTORY.md`, git push, ZIP archive | M4 | IN_PROGRESS (worker_r3_m5 executing) |

## Interface Contracts
### `runner.js` ↔ `accounts.js` / `queue.js`
- `handleAccountFailure({ bot, accountId, failure, retryAfterSeconds, reason, ... })`:
  - When `failure === 'ambiguous'` or `reason` is ambiguous, increment `acc.failures`, set cooling, evaluate `acc.failures >= 3` -> mark isolated `معزول (3 إخفاقات)`, send single isolation notification.
  - When `failure === 'network_proxy_error'` or error is VPN/proxy related, do NOT increment `acc.failures`; apply short backoff or retry with next proxy slot.
- `queue.recoverProcessing({ state, reason })`:
  - Preserve items in `claimed` phase (pre-dispatch); reset to `pending` so unattempted posts are not lost.
  - Mark only `dispatch_started` items as `ambiguous`.

### `runner.js` ↔ `linkExports.js`
- `linkExports.enqueueTerminal(run)`:
  - Compute hash / item set of daily rows.
  - If identical to the most recent successful delivery in `state.linkDeliveries` for that chat and day, suppress new outbox entry.

### `runner.js` ↔ `direct_x_bridge.py`
- Python bridge output schema: `{ success: boolean, published: boolean, url: string|null, tweetId: string|null, reason: string|null, accountFailure: string|null, rateLimit: boolean, retryAfterSeconds: number|null }`.

## Code Layout & File Boundaries
- **Milestone M1 (DONE)**: `Bot/src/runner.js`, `Bot/src/queue.js`, `Bot/src/accounts.js`, `Bot/test/m1_fixes_comprehensive.test.js`, `Bot/test/challenger_iter2_concurrency_fuzz.test.js`.
- **Milestone M2 (worker_r3_m2 exclusive ownership)**: `Bot/python/direct_x_bridge.py`, `Bot/python/direct_x_compat.py`, `Bot/python/test_*.py`.
- **Milestone M3 (worker_r3_m3 exclusive ownership)**: `Bot/src/linkExports.js`, `Bot/src/telegramUi.js`, `Bot/src/singleInstance.js`, `Bot/test/m3_*.test.js`.
- **Milestone M4 (Live Operational Validation)**: `Bot/test/live_vps_*.js`, live configuration, test runner scripts in isolated `/tmp/yj_test_*` directory.
- **Milestone M5 (Audit & Reports)**: `RESOURCE_CLEANUP_REPORT.md`, `MASTER_TODO.md`, `PROGRESS_HISTORY.md`.

